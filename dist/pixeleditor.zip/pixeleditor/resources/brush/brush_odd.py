#!/usr/bin/env python
#-*- coding: utf-8 -*-

name = "odd"
icon = "brush_odd.png"
function = lambda n : not n % 2
