#!/usr/bin/env python
#-*- coding: utf-8 -*-

name = "even"
icon = "brush_even.png"
function = lambda n : n % 2
