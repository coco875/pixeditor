#!/usr/bin/env python
#-*- coding: utf-8 -*-

name = "solid"
icon = "brush_solid.png"
function = lambda n : True
