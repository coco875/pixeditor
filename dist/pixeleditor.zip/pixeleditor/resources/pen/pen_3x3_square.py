#!/usr/bin/env python
#-*- coding: utf-8 -*-

name = "3x3 square"
icon = "pen_3x3_square.png"
pixelList = ((-1, -1), (-1, 0), (-1, 1),
             ( 0, -1), ( 0, 0), ( 0, 1),
             ( 1, -1), ( 1, 0), ( 1, 1))
