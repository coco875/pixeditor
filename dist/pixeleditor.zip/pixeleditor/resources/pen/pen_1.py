#!/usr/bin/env python
#-*- coding: utf-8 -*-

name = "point"
icon = "pen_1.png"
pixelList = ((0, 0),)
