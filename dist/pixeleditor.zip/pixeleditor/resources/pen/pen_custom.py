#!/usr/bin/env python
#-*- coding: utf-8 -*-

name = "custom"
icon = "pen_custom.png"
pixelList = ()
