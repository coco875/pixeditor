#!/usr/bin/env python
#-*- coding: utf-8 -*-

name = "2 pixels vertical"
icon = "pen_2_vert.png"
pixelList = ((0, 0),
             (0, 1))
