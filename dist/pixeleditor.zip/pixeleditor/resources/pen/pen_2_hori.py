#!/usr/bin/env python
#-*- coding: utf-8 -*-

name = "2 pixels horizontal"
icon = "pen_2_hori.png"
pixelList = ((0, 0), (1, 0))
