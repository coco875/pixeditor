#!/usr/bin/env python
#-*- coding: utf-8 -*-

name = "2x2 square"
icon = "pen_2x2_square.png"
pixelList = ((0, 0), (0, 1),
             (1, 0), (1, 1))
