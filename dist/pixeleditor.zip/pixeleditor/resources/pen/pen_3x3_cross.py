#!/usr/bin/env python
#-*- coding: utf-8 -*-

name = "3x3 cross"
icon = "pen_3x3_cross.png"
pixelList = ((-1, 0),
    (0, -1), ( 0, 0), (0, 1),
             ( 1, 0))
