The following file:

  convert.exe

is part of ImageMagick®, and redistributed with pixeditor on Windows, in order
to export animated GIF images. The file is taken from version 6.8.1-Q8,
static build for x86 (32bit) Windows systems.

ImageMagick® is a software suite to create, edit, compose, or convert bitmap
images.  It is distributed under the Apache 2.0 license, approved by the OSI
and recommended for use by the OSSCC. See License.txt in this directory for the
full license.

http://www.imagemagick.org/
